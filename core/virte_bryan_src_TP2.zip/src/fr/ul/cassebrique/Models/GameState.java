package fr.ul.cassebrique.Models;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import fr.ul.cassebrique.DataFactories.TextureFactory;

enum State{
    Running,
    BallLoss,
    GameOver,
    Won,
    Pause,
    Quit
}

public class GameState {

    private State state;
    private int nbBalls;
    private Texture tex;

    public GameState() {
        this.state = State.Running;
        this.nbBalls = 3;
        this.tex = TextureFactory.getTexBall();
    }

    public State getState() {
        return state;
    }

    public int getNbBalls() {
        return nbBalls;
    }

    public void draw(SpriteBatch sb){
        for (int i =0; i<nbBalls-1;i++)
            sb.draw(tex, Gdx.graphics.getBackBufferWidth()-50+(50-tex.getWidth())/2,i*(tex.getHeight()+10)+10);
    }
}

