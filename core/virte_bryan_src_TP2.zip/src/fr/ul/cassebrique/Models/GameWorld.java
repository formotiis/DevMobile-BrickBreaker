package fr.ul.cassebrique.Models;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import fr.ul.cassebrique.Views.GameScreen;

public class GameWorld {

    private GameScreen gs;
    private GameState gameState;
    private Wall wall;
    private Background bg;
    private Racket racket;
    private final static int timeIter = 1000/60;


    public GameWorld(GameScreen g){
        this.gs = g;
        this.bg = new Background();
        this.racket = new Racket(this);
        this.gameState = new GameState();
        this.wall = new Wall();
    }

    public void draw(SpriteBatch s){
        bg.draw(s);
        racket.draw(s);
        wall.draw(s);
        gameState.draw(s);
    }

    public Racket getRacket() {
        return racket;
    }

    public static long getTimeIter(long time) {
        return timeIter-time;
    }
}
