package fr.ul.cassebrique.Models;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import fr.ul.cassebrique.DataFactories.TextureFactory;

public class Background {

    private Texture bg;

    public Background() {
        bg = TextureFactory.getTexBack();
    }

    public void draw(SpriteBatch sb){
        sb.draw(bg ,0,0);
    }
}
